# PALETTE — D.F. Nails Studio (Waalwijk)

Name: **Jade Lacquer & Papaya** ("jade-groene lak + papaya-kleurige lak").
Formula (★ ГЛАВНЫЙ СТИЛЬ): ONE deep dark base + ONE light + ONE bright accent (+ surface + muted text).

## Tokens

```css
:root{
  /* base — deep jade / bottle-green lacquer, almost black */
  --base:#021A12;
  --base2:#0A2A1F;        /* surface: cards, glass fills, gradient stops between sections */
  /* light — nude porcelain (skin tone of a bare nail, slightly warm) */
  --light:#F4E4DA;
  --muted:#A9BFB3;        /* sage-mist secondary text (solid; or rgba(244,228,218,.68)) */
  /* accent — papaya / coral nail polish */
  --accent:#FF7448;
  --accent-ink:#2A0C03;   /* text on accent buttons */
  --accent-glow:rgba(255,116,72,.38); /* light in the hero render, particles, card cursor-glow */
  /* glass UI */
  --glass:rgba(244,228,218,.07);
  --glass-b:rgba(244,228,218,.16);
}
```

Usage: `body{background:var(--base);color:var(--light)}`. The accent goes only on the main CTA (Boek via Fresha),
on the light/glow in photo renders, on small icons and focus rings. Never on large areas or body text.
Hero/scenes: a polished nail / bottle of lacquer in dark jade gloom, lit from the side by papaya-coral light
with a chrome glint; the nude-porcelain tone reads as skin and pearl.

## Why this palette
- Comes from the product: deep green "bottle" lacquer (a classic dark-luxury nail colour), a bright
  papaya/coral polish as the light source, and nude porcelain = skin + BIAB-nude look.
- Clearly different from earlier sites: scena-piekna was wine-black + pink, warta was ink-navy + red.
  This one is green-black + warm orange-coral: different hue family on both base and accent.
- Fits a premium-studio mood without looking like the obligatory "pink for nails".

## Alternatives considered (3 variants)
1. **Jade Lacquer & Papaya** — #021A12 / #F4E4DA / #FF7448 — chosen.
2. Aubergine Chrome — #150A1E / #F3EEF6 / #C8FF4A (lime polish). Rejected: base too near scena's
   wine-black on screen, lime glow hard to make look like skin-friendly beauty light.
3. Graphite Chrome & Lilac — #0C0D10 / #F2F2F4 / #B98CFF. Rejected: "black + one accent" is
   forbidden as banal in references/PALETTES.md, and graphite reads cold/techy.

## Contrast (WCAG 2.x, computed with a python script — not guessed)
| Pair | Ratio | Verdict |
|---|---|---|
| light #F4E4DA on base #021A12 | 14.63 : 1 | AAA |
| light on surface #0A2A1F | 12.43 : 1 | AAA |
| muted #A9BFB3 on base | 9.31 : 1 | AAA |
| muted on surface | 7.91 : 1 | AAA |
| accent #FF7448 on base (icons, links, small text) | 6.77 : 1 | AA (≥4.5) |
| accent on surface | 5.75 : 1 | AA |
| accent-ink #2A0C03 on accent (button label) | 6.81 : 1 | AA |
| base #021A12 on accent (alt button label) | 6.77 : 1 | AA |

## Distance from earlier sites (CIE76 ΔE, Lab)
| New | vs scena-piekna | vs warta-supermarkt |
|---|---|---|
| base #021A12 | 17 (vs #14040A) | 19 (vs #0A1626) |
| accent #FF7448 | 57 (vs #FF3E92) | 22 (vs #F2382B) |
| light #F4E4DA | 6 (vs pearl) | 6 (vs ivory) |

All main colours ≥ ΔE 10 from previous ones except the light tone: the formula requires
white/pearl/ivory, so all light tones are near each other by definition; nude-porcelain is the
warmest/pinkest of the three and differs visibly next to its jade base.

Journal row (for the orchestrator): `| df-nails-studio (cinematic) | база jade #021A12 · nude porcelain #F4E4DA · акцент papaya #FF7448 | surface #0A2A1F / muted #A9BFB3 |`

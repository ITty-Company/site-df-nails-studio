# COPY — D.F. Nails Studio (Waalwijk)

Rol: copywriter · input: BRIEF.md, STORY.md · taal: Nederlands.
Alleen feiten uit BRIEF: acryl, BIAB, pedicure · boeken via Fresha · Instagram @df.salonbeauty · 06 26 77 04 92 ·
Molenvlietstraat 1, Waalwijk. Geen prijzen, geen openingstijden (→ «zie Fresha»), geen reviews, geen jaartallen, geen namen.

Links (voor builder):
- `FRESHA` = https://www.fresha.com/a/d-f-nails-studio-waalwijk-molenvlietstraat-1-hlhzji0v
- `TEL` = tel:+31626770492
- `IG` = https://www.instagram.com/df.salonbeauty
- `ROUTE` = https://www.google.com/maps/search/?api=1&query=Molenvlietstraat+1+Waalwijk

---

## Gedeeld (alle pagina's)

**Navigatie:** Home · Behandelingen · Over ons · Contact · pil-knop: `Plan je afspraak` → FRESHA
**Logo-tekst:** D.F. Nails Studio · sub: Nagelstudio · Waalwijk
**Mobiel menu, onderaan:** `Bel 06 26 77 04 92` → TEL
**Skip-link:** Naar inhoud
**Beeldlabel (onder elk beeld met handen/voeten):** Voorbeeldbeeld
**Paginatitels voor de overgangsgordijn:** home. · behandelingen. · over ons. · contact.

**Finale (gedeeld, onderaan elke pagina)**
- h2: **tot zo in de studio.**
- tekst: Kies je behandeling en een moment dat jou past — online, wanneer het jou uitkomt.
- knoppen: `Plan je afspraak` → FRESHA · `Bel 06 26 77 04 92` → TEL

**Footer**
- D.F. Nails Studio · Molenvlietstraat 1, Waalwijk
- Afspraken via Fresha · 06 26 77 04 92 · Instagram @df.salonbeauty
- Openingstijden: zie Fresha
- Home · Behandelingen · Over ons · Contact
- **Ontwerpvoorstel — ITty Company.** Afbeeldingen zijn voorbeeldbeelden en worden vervangen door eigen werk van de studio.

**Meta**
- title: D.F. Nails Studio — nagelstudio in Waalwijk · BIAB, acryl & pedicure
- description: Nagelstudio aan de Molenvlietstraat 1 in Waalwijk. BIAB, acrylnagels en pedicure. Plan je afspraak online via Fresha.

---

## HOME (`index.html`)

### Hero — glans
- chip: **Nagelstudio · Waalwijk**
- h1: **nagels die het licht vangen.**
- lead: BIAB, acryl en pedicure aan de Molenvlietstraat in Waalwijk. Rustig, precies en met aandacht — van je eigen nagel tot de laatste glanslaag.
- knoppen: `Plan je afspraak` → FRESHA · `Bel 06 26 77 04 92` → TEL
- glazen plaatjes:
  - icoon nagel — **BIAB · Acryl · Pedicure** — behandelingen
  - icoon pin — **Molenvlietstraat 1** — Waalwijk
  - icoon kalender — **Online boeken** — via Fresha
- tabbalk: Puur · Vorm · Kleur · Pedicure
- scroll-hint: scroll en volg de nagel

### Hoofdstuk 1 — puur
- teller: de nagel · 1 / 7
- h2: **alles begint bij je eigen nagel.**
- Voordat er ook maar een laag of kleur aan te pas komt, kijken we naar wat er al is: jouw natuurlijke nagel. Hoe sterk is hij, hoe ziet de nagelriem eruit, waar wil hij naartoe? Een mooie set staat of valt met een gezonde basis, en die basis is bij iedereen anders.
- Sommige nagels zijn dun en buigzaam, andere stevig maar snel droog. Sommige mensen willen vooral dat hun nagels niet meer breken, anderen dromen van lengte of een uitgesproken kleur. Door eerst goed te kijken, weet je welke behandeling bij jouw nagels past — in plaats van andersom.
- Daarom begint een afspraak niet met de kwast, maar met een moment van aandacht. Puur, zonder haast. Pas als duidelijk is wat jij wilt en wat je nagels nodig hebben, gaan we verder.
- feiten: Eerst kijken, dan kiezen · Voor elke nageltype een aanpak

### Hoofdstuk 2 — vorm
- teller: de nagel · 2 / 7
- h2: **vorm geven met geduld.**
- Een nagel krijgt zijn karakter door zijn vorm. Rond en natuurlijk, zacht ovaal, elegant amandel of strak vierkant: elke vorm geeft je hand een ander gevoel. De juiste keuze hangt af van je vingers, je dagelijkse bezigheden en wat jij mooi vindt.
- Vormen gaat stap voor stap. Rustig vijlen, steeds opnieuw kijken, links en rechts gelijk houden. Daarna wordt het oppervlak voorbereid en de nagelriem netjes verzorgd, zodat alles wat erna komt goed hecht en strak aansluit.
- Het is het deel van een behandeling dat je achteraf het minst ziet, maar het meest merkt. Goede voorbereiding is wat een set mooi laat blijven, ook als de dagen voorbij gaan.
- interactief: **kies je vorm** — rond · ovaal · amandel · vierkant
- feiten: Vijlen op maat · Zorgvuldige voorbereiding

### Hoofdstuk 3 — kracht
- teller: de nagel · 3 / 7
- h2: **een laag die je nagel draagt.**
- Voor nagels die sterker, langer of gewoon mooier mogen zijn, zijn er twee bekende technieken: BIAB en acryl. Allebei geven ze je nagel een stevige laag die beschermt en vorm geeft — maar ze werken elk op hun eigen manier.
- schakelaar **BIAB**: BIAB staat voor Builder In A Bottle: een gelachtige opbouwlaag die over je eigen nagel wordt aangebracht en onder een lamp uithardt. Het resultaat oogt natuurlijk en voelt licht, terwijl je nagel extra stevigheid krijgt. Fijn als je je eigen nagels wilt laten groeien of gewoon een verzorgde, sterke basis wilt.
- schakelaar **Acryl**: Acryl ontstaat uit een poeder en een vloeistof die samen een sterke, vormbare massa maken. Daarmee kun je nagels verlengen en precies de vorm geven die je wilt. Acryl is een klassieker voor wie houdt van lengte, karakter en een set die opvalt.
- Welke techniek bij jou past? Dat hangt af van je eigen nagels en van wat je zoekt. Twijfel je, kies dan gewoon een moment via Fresha en vraag het tijdens je afspraak — samen kijk je wat het beste werkt.
- feiten: BIAB · Acryl · Advies tijdens je afspraak

### Hoofdstuk 4 — kleur
- teller: de nagel · 4 / 7
- h2: **dan komt de kleur.**
- Als de basis staat, is het tijd voor het moment waar veel mensen naar uitkijken: de kleur. Een zacht nude dat je eigen nagel mooier maakt, een diep donker groen voor de winter of een warm papaya dat meteen zomer roept — kleur zegt iets over jou.
- Een kleur ziet er op elke hand anders uit. Je huidtint, het licht buiten en zelfs de vorm van je nagel veranderen hoe een tint overkomt. Daarom loont het om rustig te kiezen en kleuren eerst naast je hand te bekijken.
- Laag voor laag wordt de kleur aangebracht, dun en gelijkmatig, tot hij precies goed staat. Geen haast, geen strepen: alleen een egale kleur waar je blij van wordt.
- interactief: **kleurproef** — nude · papaya · jade · chroom
- onderschrift: Kleurvoorbeeld — de echte kleuren zie je in de studio.

### Hoofdstuk 5 — af
- teller: de nagel · 5 / 7
- h2: **handen die je graag laat zien.**
- Een laatste glanslaag, een blik in het licht, en dan is het af. Je handen zie je de hele dag: als je typt, kookt, iemand een hand geeft of je koffie vasthoudt. Een verzorgde set geeft rust en een klein beetje trots, elke keer als je naar beneden kijkt.
- Met een paar gewoontes blijft dat gevoel langer. Een druppel nagelriemolie voor het slapen, handschoenen bij de afwas en je nagels niet als gereedschap gebruiken — kleine dingen die thuis het verschil maken.
- knop: `Bekijk behandelingen` → behandelingen.html

### Hoofdstuk 6 — voeten
- teller: de nagel · 6 / 7
- h2: **ook je voeten verdienen aandacht.**
- Je voeten dragen je de hele dag, maar krijgen vaak de minste aandacht. Een pedicure is daarom meer dan mooie teennagels: het is een moment waarop je even stilzit en iemand anders voor je zorgt.
- Teennagels worden netjes geknipt en gevijld, de nagelriemen verzorgd en de huid zachter gemaakt. Wie wil, kiest daarna een kleur, zodat je voeten klaar zijn voor open schoenen, het strand of gewoon voor jezelf.
- Ook buiten het zomerseizoen is een pedicure een fijne gewoonte. Verzorgde voeten lopen prettiger, en wie ooit met warme sokken uit een behandeling stapte, weet hoe goed dat voelt.
- feiten: Pedicure · Te boeken via Fresha

### Hoofdstuk 7 — waalwijk
- teller: de nagel · 7 / 7
- h2: **de deur staat open.**
- Je vindt D.F. Nails Studio aan de Molenvlietstraat 1 in Waalwijk. Afspraken maak je online via Fresha: daar zie je welke behandelingen er zijn, welke tijden nog vrij zijn en wat bij jouw week past. Zo hoef je niet te bellen tijdens je werk en boek je ook 's avonds laat nog even je volgende afspraak.
- Liever eerst iets vragen? Bel dan naar 06 26 77 04 92. En wil je zien hoe sets eruit kunnen zien, of op de hoogte blijven? Volg de studio op Instagram via @df.salonbeauty.
- glazen plaatjes:
  - **Molenvlietstraat 1** — Waalwijk
  - **Online boeken** — via Fresha
  - **06 26 77 04 92** — bellen
  - **@df.salonbeauty** — Instagram
- knoppen: `Plan je afspraak` → FRESHA · `Route plannen` → ROUTE

(Finale + footer: zie Gedeeld.)

---

## BEHANDELINGEN (`behandelingen.html`)

### Hero
- chip: **BIAB · Acryl · Pedicure**
- h1: **drie manieren om te stralen.**
- lead: Van een sterke, natuurlijke basis tot lengte en karakter, en van je vingertoppen tot je tenen. Kies wat bij je past en plan je afspraak online.
- knoppen: `Plan je afspraak` → FRESHA · `Bel 06 26 77 04 92` → TEL

### Lint — acryl
- groot woord: acryl
- h2: **lengte en karakter.**
- Acryl is gemaakt van een poeder en een vloeistof die samen een stevige, vormbare laag vormen. Daarmee worden nagels verlengd of versterkt en krijgen ze precies de vorm die jij wilt — van subtiel tot uitgesproken.
- **Voor wie:** voor wie houdt van lengte, van een opvallende set, of voor wie de eigen nagels te kort of te zwak vindt om mee te werken.
- **Hoe het gaat:** de natuurlijke nagel wordt voorbereid, daarna wordt de acryl laag voor laag opgebouwd, in vorm gevijld en afgewerkt met kleur of glans.
- **Onderhoud:** omdat je eigen nagel doorgroeit, wordt een acrylset na verloop van tijd bijgewerkt. Vraag tijdens je afspraak wat voor jou een goed moment is.

### Lint — biab
- groot woord: biab
- h2: **sterk, maar natuurlijk.**
- BIAB — Builder In A Bottle — is een opbouwgel die over je eigen nagel wordt gelegd. Het geeft extra stevigheid, terwijl het resultaat licht en natuurlijk oogt. Mooi in nude of transparant, of als basis onder een kleur.
- **Voor wie:** voor wie de eigen nagels wil laten groeien, last heeft van breken of splijten, of gewoon een verzorgde, rustige look zoekt.
- **Hoe het gaat:** vormen en voorbereiden, de builder aanbrengen en uitharden onder de lamp, daarna eventueel een kleur en een glanzende toplaag.
- **Onderhoud:** ook BIAB groeit mee met je nagel en wordt op tijd bijgewerkt. Thuis helpt nagelriemolie om alles soepel te houden.

### Lint — pedicure
- groot woord: pedicure
- h2: **even voor je voeten.**
- Een pedicure geeft je voeten de aandacht die ze de rest van het jaar zelden krijgen. Teennagels worden verzorgd en in vorm gebracht, de huid voelt daarna zachter, en wie wil, sluit af met kleur.
- **Voor wie:** voor iedereen die verzorgde voeten wil — voor de zomer, voor een bijzondere dag of gewoon omdat het fijn is.
- **Hoe het gaat:** voeten ontspannen, nagels knippen en vijlen, nagelriemen verzorgen en de huid verzorgen, eventueel afgewerkt met een kleur naar keuze.
- **Onderhoud:** goed insmeren en schoenen die lekker zitten maken veel verschil tussen twee afspraken.

(Bij elk lint: knop `Plan je afspraak` → FRESHA · beeldlabel Voorbeeldbeeld)

### Prijzen & tijden
- h3: **prijzen en beschikbaarheid.**
- tekst: De actuele behandelingen, prijzen en vrije tijden vind je altijd op Fresha. Daar kies je zelf je moment.
- knop: `Bekijk op Fresha` → FRESHA

---

## OVER ONS (`over-ons.html`)

### Hero
- chip: **Molenvlietstraat 1 · Waalwijk**
- h1: **aandacht tot in de nagelriem.**
- lead: Een nagelstudio in Waalwijk voor acryl, BIAB en pedicure. Een plek waar je even stilzit en alleen je handen of voeten aan de beurt zijn.
- knoppen: `Plan je afspraak` → FRESHA · `Volg op Instagram` → IG

### Aandacht (tekst kleurt in bij scroll)
- h2: **klein werk, groot verschil.**
- Nagels zijn precisiewerk. Een millimeter te veel gevijld, een laag die net niet egaal ligt — je ziet het niet altijd meteen, maar je voelt het later wel. Daarom draait een goede behandeling om geduld: kijken, vormen, opbouwen en afwerken, in die volgorde en zonder stappen over te slaan.
- Tegelijk is een afspraak ook gewoon een moment voor jezelf. Je telefoon even weg, je handen op tafel en iemand die aandacht heeft voor wat jij mooi vindt. Dat mag rustig gaan.

### Zo verloopt je afspraak (lijn tekent zich bij scroll)
- h2: **van boeking tot glans.**
- **Boeken** — Kies je behandeling en tijd online via Fresha.
- **Welkom** — Je vertelt wat je wilt; samen kijk je naar je nagels.
- **Vorm** — Vijlen en voorbereiden, rustig en precies.
- **Laag** — BIAB of acryl, opgebouwd tot een sterke basis.
- **Kleur** — Een tint die bij jou en het moment past.
- **Af** — Een laatste glanslaag en je bent klaar om te gaan.

### Plaats voor echt werk
- h3: **hier komt het echte werk.**
- tekst: Op deze plek komen foto's van sets en van de studio zelf. Tot die tijd zie je het werk op Instagram.
- knop: `Bekijk @df.salonbeauty` → IG

---

## CONTACT (`contact.html`)

### Hero
- chip: **Online boeken via Fresha**
- h1: **tot aan de molenvlietstraat.**
- lead: Plan je afspraak online, bel even of kom langs aan de Molenvlietstraat 1 in Waalwijk.
- knoppen: `Plan je afspraak` → FRESHA · `Route plannen` → ROUTE

### Gegevens (glazen raster)
- **Adres** — Molenvlietstraat 1, Waalwijk · `Route plannen` → ROUTE
- **Afspraak** — Online via Fresha · `Plan je afspraak` → FRESHA
- **Telefoon** — 06 26 77 04 92 · `Bel 06 26 77 04 92` → TEL
- **Instagram** — @df.salonbeauty · `Volg op Instagram` → IG
- **Openingstijden** — zie Fresha

### Kaart
- h3: **je vindt ons in waalwijk.**
- tekst: Molenvlietstraat 1, Waalwijk (Noord-Brabant).
- knop: `Open in Google Maps` → ROUTE

### Kort & handig
- **Hoe maak ik een afspraak?** Via Fresha kies je zelf je behandeling en een vrij moment.
- **Ik twijfel tussen BIAB en acryl.** Boek de behandeling die het dichtst in de buurt komt en bespreek het tijdens je afspraak, of bel even vooraf.
- **Wat zijn de prijzen en openingstijden?** Die staan altijd actueel op Fresha.

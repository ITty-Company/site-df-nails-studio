# TYPE — D.F. Nails Studio (Waalwijk)

Pair: **Outfit 300** (display) + **Manrope 400/500** (body/UI). 3 styles total.

- Outfit: geometric grotesk with round, soft bowls (o, a, e look like smooth nail tips / pebbles of gel);
  at 300 it gives the thin, huge, lowercase cinematic heading from the standard.
- Manrope: slightly technical, very legible on phones at 16–18px; its tighter, more "engineered"
  forms contrast with Outfit's roundness so the pair isn't one-font-twice.
- Not used before: scena-piekna = Urbanist, warta = Sora + Figtree (journal/fonts.md).
- Dutch: both cover latin + latin-ext on Google Fonts (é ë ï ó ö, "ĳ" written as i+j). Check strings like
  «Behandelingen», «Openingstijden», «één», «café», «geïnteresseerd» render without fallback.

## Google Fonts
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500&family=Outfit:wght@300&display=swap" rel="stylesheet">
```
(Or self-host the same 3 woff2 files in `assets/fonts/` with `font-display:swap`.)

## Tokens & scale
```css
:root{
  --f-display:'Outfit',system-ui,sans-serif;
  --f-body:'Manrope',system-ui,sans-serif;
}
body{font:400 clamp(16.5px,1.05vw + 12px,18.5px)/1.62 var(--f-body);letter-spacing:0;}
h1,h2,h3{font-family:var(--f-display);font-weight:300;text-transform:none;margin:0}
h1{font-size:clamp(3rem,7.6vw,7.8rem);line-height:.96;letter-spacing:-.04em}   /* 3–4 lines, lowercase, ends with a dot */
h2{font-size:clamp(2.3rem,5vw,5.2rem);line-height:1.0;letter-spacing:-.035em}
h3{font-size:clamp(1.45rem,2.2vw,2.1rem);line-height:1.12;letter-spacing:-.02em}
.lead{font:400 clamp(1.05rem,1.25vw,1.3rem)/1.55 var(--f-body);color:var(--muted)}
.stat-num{font:300 clamp(2rem,3.4vw,3rem)/1 var(--f-display);letter-spacing:-.03em}
.chip,.btn,.nav a{font:500 .9rem/1 var(--f-body);letter-spacing:.01em}
.eyebrow-small{font:500 .78rem/1.2 var(--f-body);letter-spacing:.08em;text-transform:uppercase} /* only for tiny tab labels / footer meta, never above every heading */
```

## Rules
- Headings lowercase as written (no CSS uppercase), short phrase with a full stop, e.g. «nagels die blijven glanzen.»
- No caps-poster, no outlines; the only caps are tiny UI labels (tracking +0.08em).
- Body max-width ~62ch; mobile body never below 16.5px.
- Weights in use: Outfit 300 only; Manrope 400 (text), 500 (buttons, nav, chips, labels).

Journal row (for the orchestrator): `| df-nails-studio | Outfit 300 | Manrope 400/500 |`

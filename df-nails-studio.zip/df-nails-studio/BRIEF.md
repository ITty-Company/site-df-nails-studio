# BRIEF — D.F. NAILS STUDIO (Waalwijk)

slug: df-nails-studio
Ниша: nagelstudio (маникюр/педикюр) — beauty:nails
Адрес: Molenvlietstraat 1, Waalwijk (Noord-Brabant)
Телефон (публичный, с карточки Fresha): +31 6 26770492 (WhatsApp вероятно тот же номер — на сайте писать «Bel of app» только как ссылку tel:/wa.me, без утверждений)
Instagram: https://www.instagram.com/df.salonbeauty
Email: неизвестен (не писать)
Запись: через Fresha — https://www.fresha.com/a/d-f-nails-studio-waalwijk-molenvlietstraat-1-hlhzji0v
Своего сайта нет — только Fresha и Instagram.

Реальные факты (из карточки Fresha в leads.csv):
- Услуги: acryl nagels, BIAB, pedicure.
- Работает по записи через Fresha.
- Находится в Waalwijk, Molenvlietstraat 1 (по этому же адресу на Fresha есть и Dolché Beauty — НЕ упоминать на сайте).

НЕИЗВЕСТНО (не выдумывать): часы работы, цены, рейтинг, число отзывов, имя мастера, год основания, бренды материалов. Где нужно — «Openingstijden: zie Fresha», цены не писать, отзывы не писать.

Язык клиентов: Nederlands (весь сайт NL).
Что плохо сейчас: нет своего сайта — клиент из Google видит только карточку Fresha/Instagram, нет страницы с услугами по-нидерландски, нет «лица» студии.
Что сказать клиенту: «У вас нет своего сайта — мы сделали демо: 4 страницы, кинематографичный стиль, кнопка записи ведёт прямо в ваш Fresha».

Источники: leads/leads.csv (fresha.com/a/d-f-nails-studio-waalwijk-molenvlietstraat-1-hlhzji0v, instagram df.salonbeauty).
Примечание: WebFetch в этом цикле был недоступен, факты не перепроверены вручную.

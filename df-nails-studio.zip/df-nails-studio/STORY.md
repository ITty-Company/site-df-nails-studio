# STORY — D.F. Nails Studio (Waalwijk)

Роль: story-architect · вход: BRIEF.md, PALETTE.md («Jade Lacquer & Papaya»), TYPE.md (Outfit 300 + Manrope 400/500),
DESIGN_STANDARD ★ ГЛАВНЫЙ СТИЛЬ (главнее всего; §0 устарел) + §9 + §10 + §11, эталон структуры `sites/scena-piekna`.
Дата: 17.11.2026

---

## 0. Главная идея

**ОДИН ОБЪЕКТ: одна рука — и один ноготь на безымянном пальце, который ведёт всю историю.**
Ноготь проходит весь путь студии: готовый глянцевый сет → назад к голому натуральному ногтю → форма и подготовка →
прозрачный слой-основа (BIAB / acryl) светится изнутри → мазок цвета papaya → снова глянцевый сет, по которому
пробегает хромовый блик → глава педикюра (та же сцена, та же «лаковая» вода) → рука тянется к светящейся двери
студии на вечерней улице Waalwijk → «Plan je afspraak».

Почему так: услуги подтверждены ровно три — **acryl, BIAB, pedicure** (BRIEF). Процесс маникюра — естественный
сюжет «от голого ногтя до готового» (§9 прямо называет его). Ничего не утверждаем о мастере, ценах, часах, брендах.

**Правило честности (обязательно для copywriter и builder):**
- Все кадры с руками/ногами (K1–K7) — сгенерированы. Под каждым мелкая подпись Manrope 500 12px `--muted`:
  `Voorbeeldbeeld` (на всех кадрах K1–K7 и везде, где они повторяются, включая hero и contact).
- В футере: `Ontwerpvoorstel — ITty Company. Afbeeldingen zijn voorbeeldbeelden en worden vervangen door eigen werk van de studio.`
- Стеклянные плашки — только факты: `BIAB · Acryl · Pedicure`, `Molenvlietstraat 1, Waalwijk`, `Online boeken via Fresha`,
  `06 26 77 04 92`, `@df.salonbeauty`. Никаких «★», «x jaar», «100+ klanten», цен, часов (часы → «zie Fresha»).
- Dolché Beauty (тот же адрес на Fresha) — НЕ упоминать нигде, в т.ч. в alt и мета.

**Якорь всех кадров руки (визуальная склейка K1–K5, K7 частично):** одна и та же камера (низкий 3/4 сбоку, 15° над
поверхностью, 100mm macro), рука входит с правого края, лежит на полированном тёмно-нефритовом камне; ногти —
в точке ≈ 62% по X / 50% по Y, рука занимает правые ~55% кадра, слева 40% пустой тёмной зоны под заголовок.
Свет: мягкий nude-porcelain key сверху слева + ОДИН papaya `#FF7448` контровой свет справа сзади + маленький
хромовый блик. Фон — глубокий jade `#021A12` с лёгкой дымкой.

---

## 1. Общая механика (Home)

- Главная = одна sticky-сцена `.story` на ~9 экранов (как `scena-piekna`: `story__stage` + `story__panel`).
  Кадр руки закреплён, текстовые панели проезжают слева (на десктопе панель занимает левые 40% — ровно пустую зону кадров).
- Прогресс главы 0..1 → кадр N-1 → N: кроссфейд через маску (круг / клин / «капля лака» — по главе), +частицы canvas
  (пыль от пилки, искры света, капли), +scale 1→1.04 и лёгкий rotate ±0.6°.
- Фоны глав (§11): BG-A (нефритовая дымка), BG-B (лак-макро), BG-C (улица Waalwijk) — сменяются **круглой волной
  из точки ногтя** (center 62%/50%); Ken Burns 1.00→1.06 на главу; параллакс от мыши ±12px (кадр руки ±6px, фон ±12px —
  два слоя дают глубину). Кадры K1–K5 дополнительно вырезаны по контуру руки (прозрачный webp) и лежат поверх фона;
  полный кадр — фолбэк без WebGL / при `prefers-reduced-motion`.
- Большое слово за рукой: Outfit 300, `clamp(8rem,22vw,26rem)`, `--light` opacity .05, частично перекрыто рукой.
  Слова — нидерландские, строчные.
- Без стыков: общий фон `--base`; у фото-слоёв градиенты в `--base` через ::before/::after секции, не mask на параллакс-картинке.
  Конец истории уходит в затемнение, финал проявляется из него.
- Индикатор: слева снизу `de nagel · 3 / 8` (Manrope 500 13px), справа точки-навигация (активная точка — papaya).
- Lenis + доводка к ближайшему кадру (snap только на десктопе).
- **Движение на всех секциях:** пылинки/искры canvas (nude, 1 из 12 papaya), дымка плывёт, хромовый блик по ногтю
  (CSS-полоса по маске ногтя раз в ~6 с), «дыхание» кадров, заголовки выезжают по словам, кнопки с бликом,
  стеклянные плашки со свечением за курсором. Всё лёгкое, только когда секция видна.

**Мобильная раскладка (все главы Home):** кадр сверху 45vh (sticky, `object-position: 64% 50%` — ногти в кадре),
большое слово по центру за рукой, текстовая панель снизу на стекле `--base2` с blur; 1-й абзац виден сразу,
остальные — «lees verder». Подпись `Voorbeeldbeeld` в правом нижнем углу кадра. Стеклянные плашки в ряд по 2–3
с переносом (wrap), никакого горизонтального скролла. Частиц вдвое меньше, разрешение canvas ×0.6.

---

## 2. Главы Home

### Глава 0 — HERO · «glans» (0 → 0.10)
- **Кадр:** K5 — готовый глянцевый сет papaya, хромовый блик на безымянном ногте. Фон BG-A.
- **Загрузка:** из тьмы проявляется рука, papaya-свет «зажигается» (2 мягкие вспышки), блик пробегает по ногтям слева
  направо, h1 выезжает по словам. Прозрачная навигация (лого слева, 4 пункта, белая пилюля `Plan je afspraak`).
- **Скролл:** текст hero растворяется, камера влетает в ноготь (scale 1→1.18 к точке ногтя) — белая вспышка-«блик»
  на 6% прогресса — переход в гл.1.
- **Слово за объектом:** `glans`.
- **Тексты:** чип; h1 (3–4 строки, строчными, с точкой); lead 1–2 предложения; кнопки: акцентная `Plan je afspraak`
  (Fresha) + контурная `Bel 06 26 77 04 92`. Стеклянные плашки: `BIAB · Acryl · Pedicure` / `Molenvlietstraat 1` /
  `Online boeken via Fresha`. Стеклянная полоса вкладок внизу hero: `Puur · Vorm · Kleur · Pedicure` → якоря на главы.
- **Мобильно:** кадр сверху 55vh, h1 4 строки, плашки 3 в ряд мелко (иконка + 1 строка), вкладки — 4 в ряд, мелко.

### Глава 1 — «puur» · голый ноготь (0.10 → 0.22)
- **Кадр:** K5 → K1. Лак «стекает» назад: маска-капля сверху вниз по каждому ногтю (SVG-маска по контуру ногтей
  кадра), papaya-искры отрываются и гаснут. Остаётся натуральный ноготь, свет становится мягче.
- **Фон:** BG-A, дымка плывёт слева направо.
- **Тексты (тема):** всё начинается с собственного ногтя: здоровый натуральный ноготь — основа; как смотрят на ногтевую
  пластину и кутикулу перед работой; естественность как отправная точка. 3 абзаца + факт-плашки.

### Глава 2 — «vorm» · форма и подготовка (0.22 → 0.36)
- **Кадр:** K1 → K2: в кадр входит тонкая пилка, у кончика ногтя — облачко светящейся пыли.
- **Переход:** клин по диагонали (как движение пилки) + canvas «пыль» nude-цвета, сыплется вниз и тает.
- **Фон:** BG-A.
- **Тексты:** форма (овал, миндаль, квадрат — общее ремесло), подготовка поверхности, почему подготовка решает,
  сколько продержится результат (без цифр). 3 абзаца.
- **Интерактив (десктоп и тач):** «kies je vorm» — 4 тонких SVG-силуэта ногтя (rond · ovaal · amandel · vierkant)
  у текста; выбранный контур подсвечивается papaya и обводится над ногтем в кадре (SVG-оверлей). Чисто визуально.

### Глава 3 — «kracht» · BIAB и acryl (0.36 → 0.52)
- **Кадр:** K2 → K3: прозрачный nude-слой builder ложится на ногти, ноготь светится изнутри мягким papaya-сиянием,
  блик перекатывается по «линзе» слоя.
- **Переход:** круглая волна из точки ногтя + «жидкое» стекло (WebGL-дисторсия 0.4 с, фолбэк — простой кроссфейд).
- **Фон:** BG-A → BG-B (круглая волна).
- **Тексты:** два способа сделать ноготь сильным: BIAB (гелевый builder поверх своего ногтя — для тех, кто хочет
  натуральный вид и укрепление) и acryl (порошок + жидкость, модель и удлинение) — общее о технике, без цифр стойкости.
  Как выбрать: зависит от своего ногтя и желания — подскажут на приёме. 3–4 абзаца.
- **Приём:** split-переключатель `BIAB | Acryl` в панели: меняются абзац и подпись к кадру (кадр тот же).

### Глава 4 — «kleur» · цвет (0.52 → 0.66)
- **Кадр:** K3 → K4: кисть кладёт papaya-лак на безымянный ноготь, остальные пока nude.
- **Переход:** «мазок» — маска-полоса слева направо по ногтю (как кисть) + 3–4 papaya-капли canvas.
- **Фон:** BG-B (лаковое макро, нефрит + papaya в боке).
- **Тексты:** цвет как финальный акцент: от nude до яркого; papaya — цвет сайта, но выбор за клиентом; про то,
  как цвет выглядит на разном оттенке кожи и при разном свете. 2–3 абзаца.
- **Интерактив «kleurproef»:** 4 стеклянных кружка-оттенка (nude porcelain, papaya, jade, chroom) — тап перекрашивает
  ногти в кадре через CSS `mix-blend-mode: color` на маске ногтей K5. Подпись: «Kleurvoorbeeld — de echte kleurkaart zie je in de studio.»

### Глава 5 — «af» · глянцевый сет (0.66 → 0.76)
- **Кадр:** K4 → K5: все ногти papaya, по ним пробегает хромовый блик (белая диагональ), свет на максимуме.
- **Переход:** клин справа налево + вспышка блика.
- **Фон:** BG-B → тёмный `--base` с papaya-ореолом за рукой.
- **Тексты:** результат: ухоженные руки, которые видно каждый день; как ухаживать дома (масло для кутикулы,
  перчатки для уборки — общее). 2 абзаца + кнопка `Bekijk behandelingen` (контурная).

### Глава 6 — «voeten» · педикюр (0.76 → 0.86)
- **Кадр:** K6 — стопа в неглубокой чаше с тёмной нефритовой водой, ногти papaya, круги на воде.
- **Переход:** рука уходит вниз, снизу «поднимается вода» — горизонтальная волна-маска + рябь (canvas-кольца из
  точки ногтя). Отдельный кадр, тот же свет и камера.
- **Фон:** тот же `--base` с отражениями воды (CSS-каустика, медленно).
- **Слово:** `voeten`.
- **Тексты:** педикюр как пауза: ухоженные стопы, ногти, комфорт в обуви и с открытыми сандалиями; общее о процессе.
  2–3 абзаца.

### Глава 7 — «waalwijk» · дорога в студию (0.86 → 0.96)
- **Кадр:** K7 — рука с готовым сетом тянется к ручке приоткрытой двери, из щели — тёплый papaya-свет.
  Затем круглая волна в BG-C (вечерняя улица Waalwijk).
- **Переход:** zoom-out + волна; дымка становится вечерним туманом.
- **Слово:** `waalwijk`.
- **Тексты:** адрес Molenvlietstraat 1, Waalwijk; запись онлайн через Fresha; openingstijden — «zie Fresha»;
  Instagram для работ; телефон. 2 абзаца + стеклянные плашки (адрес / Fresha / телефон / Instagram).
- **Кнопки:** `Plan je afspraak` + `Route plannen` (Google Maps по адресу).

### Финал (0.96 → 1.0, затем секция `.finale`)
- K7 уходит в затемнение, остаётся papaya-свет из двери → проявляется BG-C крупно (Ken Burns) с искрами
  (canvas `sparks`, nude + 1 из 10 papaya, поднимаются вверх).
- **Тексты:** короткий h2 с точкой, 1 строка, кнопки `Plan je afspraak` + `Bel 06 26 77 04 92`.
- **Футер:** адрес, телефон, Instagram, Fresha, `Ontwerpvoorstel — ITty Company`.

Объём Home ≥ 900 слов (COPY.md).

---

## 3. Внутренние страницы (каждая со своим кинематографичным hero и движением)

### Behandelingen (`behandelingen.html`)
- **Hero:** H-BEH (натюрморт инструментов: баночка акрилового порошка, флакон builder-геля, кисть, papaya-флакон,
  край чаши для педикюра) справа, слева пусто. Пыль в луче, блик по стеклу флаконов.
- **Приём — закреплённая горизонтальная лента из 3 «сцен»** (не карточки): `acryl` · `biab` · `pedicure`.
  Каждая сцена = огромное слово Outfit 300 + 2–3 абзаца + «voor wie / hoe het gaat / onderhoud» (общее ремесло)
  + кнопка `Plan je afspraak`. Визуал сцены — кропы K3 / K5 / K6 (`object-position`) с подписью `Voorbeeldbeeld`.
  На телефоне лента становится вертикальной (без горизонтального скролла).
- **Блок «Prijzen & tijden»:** одна стеклянная плашка: «Actuele behandelingen, prijzen en beschikbaarheid zie je op Fresha.» + кнопка.
- Финал общий.

### Over ons (`over-ons.html`)
- **Hero:** H-OVER — пустой маникюрный стол под лампой в нефритовой полутьме, papaya-отсвет от флакона.
- **Секция «aandacht»:** текст прокрашивается по словам при скролле (nude ← muted).
- **Линия-процесс** (рисуется SVG-путём при скролле, papaya-точка едет): Fresha → welkom → vorm → laag → kleur → af.
- **Блок-заглушка (§7):** пунктирная рамка `--glass-b`: «Hier komen foto's van het echte werk en de studio» + ссылка на Instagram.
- Никаких имён, лет, историй основания.

### Contact (`contact.html`)
- **Hero:** BG-C (вечерняя улица, свет из двери студии) — без людей.
- **Стеклянная сетка:** Adres · Afspraak (Fresha) · Telefoon · Instagram · Openingstijden «zie Fresha». Email НЕ ставить.
- **Карта:** тёмная SVG-схема кодом (без тайлов) с papaya-точкой + кнопка «Open in Google Maps».
- Финал общий.

---

## 4. Переход между страницами
Шторка из 2 слоёв: `--base2` снизу вверх, за ней `--base`; по центру тонкий SVG-контур ногтя (1px `--light`),
который «заливается» papaya снизу вверх, как лак; под ним название страницы Outfit 300 строчными
(`behandelingen.` / `over ons.` / `contact.` / `home.`). Вперёд по меню — снизу вверх, назад — сверху вниз;
контент уходит `rotateX(6deg) translateZ(-80px)`. На телефоне без 3D-наклона. `prefers-reduced-motion` → простой fade.

## 5. Интерактивы (итого 3)
1. **Kies je vorm** — гл.2 (SVG-силуэты формы над ногтем).
2. **BIAB | Acryl** — гл.3 и Behandelingen (переключатель объяснения).
3. **Kleurproef** — гл.4 (перекраска ногтей в кадре, подпись-оговорка).

---

## 6. ПРОМПТЫ — Higgsfield `gpt_image_2_6` (ровно 12 картинок)

### Общий якорь (дословно в начало K1–K5 и K7)
```
ANCHOR: Cinematic premium beauty advertising macro photograph. Camera: low three-quarter side view, 15 degrees above the surface, 100mm macro lens, shallow depth of field. One elegant relaxed left hand with a natural light-warm skin tone and realistic skin texture enters from the right edge of the frame, back of the hand toward the camera, fingers gently curved, fingertips resting on a polished dark jade-black stone surface. The nails are positioned at about 62% from the left and 50% from the top; the hand occupies the right 55% of the frame. The left 40% of the frame is empty, very dark negative space. Background: deep jade-black #021A12 gloom with faint drifting haze. Lighting: soft nude porcelain #F4E4DA key light from the upper left; ONE single papaya-coral #FF7448 rim glow from behind on the right, catching the edges of the fingers and nails; a tiny chrome specular glint. Only one warm accent color in the image. Fine film grain, rich shadows, quiet luxury. No jewelry, no rings, no text, no logos, no face.
```

| # | ID / файл | Где | Формат | Референс | Промпт |
|---|---|---|---|---|---|
| 1 | **K1** `k1-bare.webp` | Home гл.1 | 16:9 | — (мастер-кадр, генерировать ПЕРВЫМ) | `ANCHOR` + `The nails are bare, natural and unpolished, short to medium length, clean and healthy with soft natural shine, natural pink nail beds and pale free edges. Nothing else in the frame.` |
| 2 | **K2** `k2-shape.webp` | Home гл.2 | 16:9 | **K1** (same hand, camera, light, position) | `ANCHOR` + `Same hand and scene as the reference image. A slim fine nail file, held by an out-of-frame hand only visible as fingertips at the right edge, touches the free edge of the ring-finger nail, shaping it into a soft almond form. A faint cloud of fine glowing dust floats at the nail tip, lit by the papaya rim light. Nails still bare.` |
| 3 | **K3** `k3-builder.webp` | Home гл.3; Behandelingen (кроп biab/acryl) | 16:9 | **K2** | `ANCHOR` + `Same hand and scene as the reference image, no file. All nails are now neatly shaped soft almond and coated with a smooth, translucent sheer-nude builder gel layer, thick and glass-like, with a clean curved apex. The coating glows softly from within where the papaya rim light passes through it, like warm light in clear resin.` |
| 4 | **K4** `k4-colour.webp` | Home гл.4 | 16:9 | **K3** | `ANCHOR` + `Same hand and scene as the reference image. A fine nail-polish brush enters from the upper right and lays a creamy papaya-coral #FF7448 lacquer onto the ring-finger nail, half covered with a fresh glossy stroke. The other nails still show the sheer-nude builder layer.` |
| 5 | **K5** `k5-gloss.webp` (= HERO) | Home hero + гл.5; Behandelingen (кроп) | 16:9 | **K4** | `ANCHOR` + `Same hand and scene as the reference image, no brush. All nails are finished in a flawless high-gloss papaya-coral #FF7448 lacquer, soft almond shape, with a crisp curved chrome highlight running across each nail. The papaya rim glow is slightly stronger. Hero composition: generous empty dark space on the left for a headline.` |
| 6 | **K6** `k6-pedicure.webp` | Home гл.6; Behandelingen (pedicure) | 16:9 | **K5** (same light, color, surface tone) | `Cinematic premium beauty advertising macro photograph, same lighting and colour as the reference image. Camera low three-quarter side view, 100mm macro. One relaxed bare foot with a natural light-warm skin tone, toes toward the left, rests in a shallow round dark jade-black stone basin filled with still dark water; only the toes and front of the foot are visible, toenails neatly finished in glossy papaya-coral #FF7448. Soft concentric ripples on the water reflect the papaya rim light. Foot placed in the right half of the frame (toes at about 60% from the left, 55% from the top), left 40% empty dark. Deep jade-black #021A12 gloom, soft nude porcelain #F4E4DA key light from the upper left, one papaya rim glow from behind right. Fine film grain. No jewelry, no text, no logos, no petals.` |
| 7 | **K7** `k7-door.webp` | Home гл.7 + финал | 16:9 | **K5** (same hand and nails, new place) | `Cinematic premium advertising photograph, the same hand with glossy papaya-coral #FF7448 almond nails as the reference image, now reaching from the right toward the brushed-brass handle of a half-open dark jade-green painted door; warm papaya #FF7448 light spills through the gap and glints on the nails. Soft nude porcelain #F4E4DA light from the upper left, deep jade-black #021A12 evening shadows. Camera three-quarter side, 85mm. Hand and door in the right half, left 40% empty and dark. No readable signs, no house numbers, no text, no logos, no face. Fine film grain, quiet luxury.` |
| 8 | **BG-A** `bg-haze.webp` | Home hero, гл.1–3 фон | 16:9 | **K1** (тот же тон, грейн) | `Cinematic abstract background plate: deep jade-black #021A12 space with slow drifting haze and soft volumetric light, a faint polished dark jade stone surface at the bottom edge fading into darkness, a soft nude porcelain #F4E4DA glow from the upper left and one papaya-coral #FF7448 haze glow from the right edge. The center of the frame is dark, calm and empty for an object overlay. No people, no hands, no objects, no text. Fine film grain, premium.` |
| 9 | **BG-B** `bg-lacquer.webp` | Home гл.3–5 фон | 16:9 | **K5** (тот же papaya и jade) | `Cinematic extreme macro background plate of glossy liquid nail lacquer: slow folds and pools of deep jade-green lacquer with mirror-like reflections, and on the far right edge a soft out-of-focus swirl of papaya-coral #FF7448 lacquer catching the light, several out-of-focus chrome bokeh highlights. Deep jade-black #021A12 dominates; soft nude porcelain #F4E4DA reflections from the upper left. The center of the frame is dark and empty for an object overlay. No bottles, no brands, no people, no text. Fine film grain.` |
| 10 | **BG-C** `bg-waalwijk.webp` | Home гл.7, финал фон, **Contact hero** | 16:9 | **K7** (та же дверь, шире) | `Cinematic evening street plate in a quiet Dutch town centre in Noord-Brabant after rain: low brick facades, wet brick pavement reflecting light, deep jade-black #021A12 blue-green dusk sky with mist, soft nude porcelain #F4E4DA street lamps, and on the right a half-open dark jade-green door spilling a warm papaya-coral #FF7448 glow onto the wet pavement. The center of the frame is calm and empty for headline overlay. No readable signs, no house numbers, no text, no logos, no people, no cars. Fine film grain, quiet luxury.` |
| 11 | **H-BEH** `h-behandelingen.webp` | Behandelingen hero | 16:9 | **BG-B** (тон) | `Cinematic still life on a polished dark jade-black stone surface: a small open glass jar of fine nude acrylic powder with a few grains spilling, an unlabelled frosted glass bottle of sheer builder gel with brushed-brass cap, a slim nail brush, a small unlabelled bottle of glossy papaya-coral #FF7448 lacquer, and the curved rim of a dark stone pedicure basin with still water at the far right edge. Objects grouped in the right half, left 40% empty and dark. Deep jade-black #021A12 gloom with haze, soft nude porcelain #F4E4DA key light from the upper left, one papaya rim glow from the right, fine dust floating in the light. No labels, no brands, no text, no people, no hands. Fine film grain.` |
| 12 | **H-OVER** `h-over-ons.webp` | Over ons hero | 16:9 | **BG-A** (тон) | `Cinematic interior plate of a calm, empty manicure table in a dark boutique nail studio at night: a dark jade-black stone tabletop, a soft folded nude porcelain towel, a slim desk lamp casting a pool of soft nude porcelain #F4E4DA light, one small unlabelled bottle of papaya-coral #FF7448 lacquer throwing a warm glow, an empty chair softly out of focus. Table in the right half of the frame, left 40% empty and dark, deep jade-black #021A12 walls with haze. No people, no hands, no text, no logos, no brands, no mirrors with reflections. Fine film grain, quiet luxury.` |

**Подписи:** K1–K7 → `Voorbeeldbeeld` везде, где показаны. BG-A/B/C, H-BEH, H-OVER — без людей, подпись не нужна
(в футере общая оговорка про voorbeeldbeelden).

**Порядок генерации (цепочка):** K1 → K2 → K3 → K4 → K5 → K6 и K7 (оба ref K5) → BG-C (ref K7);
параллельно BG-A (ref K1), BG-B (ref K5); затем H-BEH (ref BG-B), H-OVER (ref BG-A).

**Проверка после генерации:** у K1–K5 рука и ногти в одной точке (допуск ±3% по X/Y), иначе выровнять сдвигом/кропом
перед кроссфейдом; 5 пальцев, анатомия без ошибок (лишний палец — перегенерировать); нет колец, текста, этикеток;
один papaya-источник. Экспорт webp 1920×1080 (q≈80) + мобильный кроп 1080×1350 с центром на ногтях.
**Вырезка:** K1–K5 — контур руки в прозрачный webp (rembg/OpenCV) для слоя поверх сменяющихся BG-A/BG-B;
маски ногтей K1 и K5 (SVG path, вручную по 5 ногтям) для «капли», «мазка» и «kleurproef».

---

## 7. Что нужно от клиента
Реальные фото работ и студии (заменят K1–K7, H-OVER), список и названия behandelingen как на Fresha, логотип,
подтверждение WhatsApp на том же номере.

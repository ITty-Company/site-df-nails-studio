# CRITIC — df-nails-studio — round 1

**Verdict: REQUEST_CHANGES. Final score 7/10** (the lowest of the six scores below). Reference: scena-piekna is 9/10.

Checks run:
- `check_site.py --shots --video` printed "OK: проблем не найдено" ("no problems found"): no console errors, no 4xx responses, no horizontal scroll.
- Images are light: 28–188 KB each, 840 KB in total.
- I also took my own Playwright shots: hero after load, 21 positions through the story on desktop, 11 on mobile, the page transition recorded on video, the heroes of the three subpages, and the scena-piekna hero on desktop and mobile.
- I looked at 10 frames from the checker's scroll video.

## Scores
| Criterion | Score | Evidence |
|---|---|---|
| Story | 8 | It is one hand, one camera and one light setup from start to finish: gloss → bare → file with dust → builder → papaya brush → gloss → foot in water → hand on the door. The arc reads well. Weak points: the K3 "builder" frame looks almost the same as K1 at desktop size, so the BIAB chapter shows no visible change. The hand-to-foot change is a plain crossfade, and halfway through you see a see-through hand floating over the foot (screenshot at 68%). K5 is used twice. |
| First-screen wow | 8 | The hero is strong and on style: dark jade, papaya glow, Outfit 300 h1, chip, 2 buttons, glass plates, tab bar. But the hand runs into the text area. "het" in the h1 and the end of the lead ("Waalwijk", "nagel tot de") sit on top of the index finger, and the "Online boeken" plate covers a nail. The reference keeps the left 40% empty. The tab bar shows **Vorm** as active on the hero. |
| Palette + fonts | 9 | Jade `#021A12`, porcelain and one papaya accent, with Outfit 300 and Manrope. The accent is used with restraint. It looks specific to this client and does not copy scena-piekna. |
| Text | 8 | The Dutch reads naturally and there is a lot of it (the home page is well over 900 words). I found no invented facts: no prices, opening hours, reviews or names. There are some language errors and slips, listed in item 6. |
| Mobile | 8 | The hero at 390 px is good: photo on top, large h1, plates in one row. The problems: between chapters there are whole screens that show only the cropped hand and an empty panel edge (screenshot at 10%). The end of the story leaves about 60% of the screen empty before "tot zo in de studio." (screenshot at 90%). The "Ontwerpvoorstel" and "Voorbeeldbeeld" pills crowd the top of the hero photo. |
| Cleanliness | 7 | The page transition has visible glitches (item 1). After chapter 7 there is a dead screen of flat colour before the finale (desktop screenshot at 92%: the top half is an empty panel area, the bottom is black). The fixed "Ontwerpvoorstel" badge sits on top of the footer links. On the behandelingen hero, the "Over ons" nav link sits over the bright cap of the perfume bottle. Over ons has large empty dark areas around the placeholder card. |

## Fixes (max 8)
1. **Page transition (every page) → it glitches in three places.**
   - What's wrong: (a) the nail mark and the word "behandelingen." fade in on top of the old page before the curtain has covered it. (b) While the curtain opens on the new page, lighter green horizontal bands are visible because the curtain panels are a different colour from `--base`. (c) The nav appears late and is clipped at the top.
   - How to fix: show the mark only once both panels have closed. Paint both panels exactly `--base` and give them no border or shadow. Hide the new page until the panels start to open, then show the nav together with the content.
2. **Home hero → the hand cuts through the h1, the lead and the third plate.**
   - What's wrong: see the First-screen wow row above.
   - How to fix: move the K5 frame on the hero so the nails sit at about 62–65% across and the fingers stop at about 42% (translateX plus a small scale-down only during the hero, then ease back to the shared anchor by 6% scroll). Alternatively, add a stronger dark radial gradient behind the text column. Keep the lead under 520 px wide and stop the plates before the first nail.
   - Also: on the hero, show no tab as active, or show **Puur** as active.
3. **Chapter 3 "kracht" (BIAB/acryl) → the change cannot be seen.**
   - What's wrong: K3 looks almost the same as K1.
   - How to fix: make the builder layer visible. Options: regenerate K3 from K2 with a thicker clear layer and a glowing apex, or add the planned in-code effects (a sheen that sweeps along the nail mask, plus a soft papaya glow under the nail plates while the chapter is active). Also make the BIAB/Acryl switch change something in the frame, for example the caption plus a longer nail outline for Acryl.
4. **Chapter 5 → 6 (hand → foot) → the crossfade double exposure looks cheap.**
   - How to fix: use the planned circular wave out of the nail point, or a ripple/water mask, so the hand is never semi-transparent on top of the foot. Finish the cut within 15% of the chapter's progress. If needed, dip briefly through the jade base.
5. **Story end → finale (desktop and mobile) → about one screen of empty dark.**
   - What's wrong: after panel 7 the stage fades to flat base and nothing is on screen until "tot zo in de studio." scrolls in.
   - How to fix: cut this fade to about 35vh. Start the street background and the h1 while the door frame is still fading out, so the finale grows out of K7 (same lamp light). Do not leave an empty viewport.
6. **Text → fix the language slips.**
   - "Voor elke nageltype een aanpak" → "Voor elk nageltype een aanpak" ("het type").
   - Contact hero h1 "tot aan de molenvlietstraat." → it is a street name, so write "tot aan de Molenvlietstraat." or rephrase it, for example "de weg naar de studio."
   - "wie ooit met warme sokken uit een behandeling stapte" is awkward → "wie ooit met zachte, warme voeten naar buiten liep, weet hoe goed dat voelt."
   - Behandelingen › pedicure › Hoe het gaat: "nagelriemen verzorgen en de huid verzorgen" repeats a word → "nagelriemen bijwerken en de huid verzorgen".
7. **Mobile story → dead screens between chapters.**
   - What's wrong: at 390 px there are positions where only the 45vh hand and an empty strip of glass show.
   - How to fix: on mobile, reduce the empty scroll between panels so the next panel starts entering as the previous one leaves (no viewport without text), or shorten each chapter's scroll length on mobile.
   - On the mobile hero, move the "Ontwerpvoorstel" pill out of the image. Put it in the footer only, or make it a small pill at the bottom left that appears after the hero.
8. **Fixed "Ontwerpvoorstel — ITty Company" badge and subpage cleanliness.**
   - The badge covers the footer links (desktop contact and over-ons). Hide it once the footer is in view.
   - On the behandelingen hero, push the bottle image down or right, or add a top gradient, so the nav links are not over the bright cap.
   - Over ons: the "hier komt het echte werk." card floats in about 1.5 screens of empty dark. Give that section a §11-style photo background (for example the studio lamp/table frame, blurred), or tighten the spacing to about 20vh.

What's good, keep it: the anchored hand frames are really consistent, the nail-shape picker and kleurproef interactions are nice, there is a lot of honest, non-invented copy, the subpage heroes are good (over-ons lamp and contact street are at reference level), the files are light and the console is clean. Fix items 1–5 and this is a 9.
